import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

class ObjectId {
  @Prop({ required: true })
  id: string;
}

class Resolved {
  @Prop({ required: true })
  _id: string;
}

class Team {
  @Prop({ required: true })
  name: string;

  @Prop({ required: true })
  home: boolean;

  @Prop({ type: Object, required: true })
  resolved: Resolved;
}

class Sport {
  @Prop({ required: true })
  id: string;

  @Prop({ required: true })
  name: string;
}

class LeagueAlias {
  @Prop({ required: true })
  name: string;

  @Prop({ required: true })
  shortname: string;

  @Prop({ required: true })
  providerId: string;

  @Prop({ required: true })
  providerGroup: string;
}

class League {
  @Prop({ required: true })
  name: string;

  @Prop({ required: true })
  shortname: string;

  @Prop({ required: true })
  description: string;

  @Prop({ required: true })
  country: string;

  @Prop({ type: Object, required: true })
  sport: Sport;

  @Prop({ required: true })
  id: string;

  @Prop({ type: [Object], required: true })
  aliases: LeagueAlias[];
}

@Schema()
export class Event extends Document {
  @Prop({ type: ObjectId, required: true })
  _id: ObjectId;

  @Prop({ required: true })
  description: string;

  @Prop({ required: true })
  timestamp: number;

  @Prop({ type: [Team], required: true })
  teams: Team[];

  @Prop({ type: League, required: true })
  league: League;

  @Prop({ required: true })
  providerId: string;

  @Prop({ required: true })
  providerGroup: string;
}

export const EventSchema = SchemaFactory.createForClass(Event);
