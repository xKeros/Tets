import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

@Schema()
export class League extends Document {
  @Prop()
  name: string;

  @Prop()
  shortname: string;

  @Prop()
  description: string;

  @Prop()
  country: string;

  @Prop({ type: Object })
  sport: {
    id: string;
    name: string;
  };
}

export const LeagueSchema = SchemaFactory.createForClass(League);
