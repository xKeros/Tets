import * as mongoose from 'mongoose';
const TeamSchema = new mongoose.Schema({
  name: String,
  home: Boolean,
  resolved: { _id: String },
});

const LeagueSchema = new mongoose.Schema({
  name: String,
  shortname: String,
  description: String,
  country: String,
  sport: {
    id: String,
    name: String,
  },
  id: String,
  aliases: [
    {
      name: String,
      shortname: String,
      providerId: String,
      providerGroup: String,
    },
  ],
});

const AliasSchema = new mongoose.Schema({
  description: String,
  providerId: String,
  providerGroup: String,
  eventId: String,
});

const ProviderSchema = new mongoose.Schema({
  _id: { $oid: String },
  primary: Boolean,
  providerGroup: { $oid: String },
});

const MarketSchema = new mongoose.Schema({
  id: String,
  name: String,
});

export const LineSchema = new mongoose.Schema({
  _id: { type: mongoose.Schema.Types.ObjectId, required: true },
  event: {
    description: String,
    timestamp: Number,
    teams: [TeamSchema],
    league: LeagueSchema,
    providerId: String,
    providerGroup: String,
    id: String,
    aliases: [AliasSchema],
  },
  book: {
    id: String,
    name: String,
  },
  line: {
    price: Number,
    points: Number,
  },
  provider: ProviderSchema,
  side: String,
  market: MarketSchema,
  timestamp: Number,
});

module.exports.LineSchema = LineSchema;
