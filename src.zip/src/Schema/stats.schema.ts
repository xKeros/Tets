import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

class Alias {
  @Prop()
  name: string;

  @Prop()
  shortname: string;

  @Prop()
  providerId: string;

  @Prop()
  providerGroup: string;
}

class League {
  @Prop()
  name: string;

  @Prop()
  shortname: string;

  @Prop()
  description: string;

  @Prop()
  country: string;

  @Prop({ type: Object })
  sport: {
    id: string;
    name: string;
  };

  @Prop()
  id: string;

  @Prop({ type: [Alias] })
  aliases: Alias[];
}

class Sport {
  @Prop()
  id: string;

  @Prop()
  name: string;
}

class Team {
  @Prop()
  name: string;

  @Prop()
  shortname: string;

  @Prop()
  nickname: string;

  @Prop({ type: League })
  league: League;

  @Prop()
  id: string;

  @Prop({ type: [Alias] })
  aliases: Alias[];
}

class StatsCategory {
  @Prop()
  overAllWon: number;

  @Prop()
  overAllLost: number;

  @Prop()
  awayWon: number;

  @Prop()
  awayLost: number;

  @Prop()
  homeWon: number;

  @Prop()
  homeLost: number;

  @Prop()
  favWon: number;

  @Prop()
  favLost: number;

  @Prop()
  udogWon: number;

  @Prop()
  udogLost: number;

  @Prop()
  overAllTie: number;

  @Prop()
  awayTie: number;

  @Prop()
  homeTie: number;

  @Prop()
  favTie: number;

  @Prop()
  udogTie: number;
}

@Schema({ collection: 'teambetstats' })
export class TeamStats extends Document {
  @Prop({ type: Object })
  stats: {
    ml: StatsCategory;
    ats: StatsCategory;
    uo: StatsCategory;
  };
}

export const TeamStatsSchema = SchemaFactory.createForClass(TeamStats);
