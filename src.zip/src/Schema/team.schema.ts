import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

class Sport {
  @Prop()
  id: string;

  @Prop()
  name: string;
}

class Alias {
  @Prop()
  name: string;

  @Prop()
  shortname: string;

  @Prop()
  providerId: string;

  @Prop()
  providerGroup: string;
}

class LeagueInfo {
  @Prop()
  name: string;

  @Prop()
  shortname: string;

  @Prop()
  description: string;

  @Prop()
  country: string;

  @Prop({ type: Sport })
  sport: Sport;

  @Prop()
  id: string;

  @Prop({ type: [Alias] })
  aliases: Alias[];
}

@Schema()
export class Team extends Document {
  @Prop()
  name: string;

  @Prop()
  shortname: string;

  @Prop()
  nickname: string;

  @Prop({ type: LeagueInfo })
  league: LeagueInfo;
}

export const TeamSchema = SchemaFactory.createForClass(Team);
