import { Resolver, Subscription } from '@nestjs/graphql';
import { LineService } from './lines.service';
import { LineDTO } from '../DTO/line.dto';

@Resolver('Line')
export class LineResolver {
  constructor(private readonly lineService: LineService) {}

  @Subscription(returns => [LineDTO])
  linesUpdated() {
    return this.lineService.subscribeToLines();
  }
}
