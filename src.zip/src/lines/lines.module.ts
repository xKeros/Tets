// src/lines/lines.module.ts
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { LineSchema } from '../Schema/Line.schema';
import { LineService } from './lines.service';
import { LineResolver } from './lines.resolver';

@Module({
  imports: [MongooseModule.forFeature([{ name: 'Line', schema: LineSchema }])],
  providers: [LineService, LineResolver],
  // controllers: [LinesController], // Define tu controlador si es necesario
  // providers: [LinesService], // Define tu servicio si es necesario
})
export class LinesModule {}
