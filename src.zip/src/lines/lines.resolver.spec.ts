import { Test, TestingModule } from '@nestjs/testing';
import { LinesResolver } from './lines.resolver';

describe('LinesResolver', () => {
  let resolver: LinesResolver;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [LinesResolver],
    }).compile();

    resolver = module.get<LinesResolver>(LinesResolver);
  });

  it('should be defined', () => {
    expect(resolver).toBeDefined();
  });
});
