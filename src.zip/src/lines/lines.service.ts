import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { PubSub } from 'graphql-subscriptions';
import { LineDTO } from '../DTO/line.dto';

@Injectable()
export class LineService {
  private readonly pubSub: PubSub;

  constructor(@InjectModel('Line') private readonly lineModel: Model<any>) {
    this.pubSub = new PubSub();
  }

  async getLines(): Promise<LineDTO[]> {
    // Lógica para obtener las líneas de la base de datos MongoDB
    return await this.lineModel.find().exec();
  }

  async subscribeToLines(): Promise<AsyncIterator<LineDTO[]>> {
    // Este método devolverá un iterador asíncrono que se actualizará cada 10 segundos
    const lines = await this.getLines();
    const intervalId = setInterval(async () => {
      const updatedLines = await this.getLines();
      this.pubSub.publish('linesUpdated', { linesUpdated: updatedLines });
    }, 10000);

    return this.pubSub.asyncIterator('linesUpdated');
  }
}
