import { Test, TestingModule } from '@nestjs/testing';
import { ElasticsearchResolver } from './elasticsearch.resolver';

describe('ElasticsearchResolver', () => {
  let resolver: ElasticsearchResolver;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ElasticsearchResolver],
    }).compile();

    resolver = module.get<ElasticsearchResolver>(ElasticsearchResolver);
  });

  it('should be defined', () => {
    expect(resolver).toBeDefined();
  });
});
