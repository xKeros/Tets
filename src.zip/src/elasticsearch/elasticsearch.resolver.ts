import { Query, Resolver } from '@nestjs/graphql';
import { ElasticsearchService } from './elasticsearch.service';

@Resolver()
export class SearchResolver {
  constructor(private readonly elasticsearchService: ElasticsearchService) {}

  @Query(() => String)
  async search() {
    const result = await this.elasticsearchService.search('player-stats-v1', {
      query: {
        match_all: {},
      },
    });
    return JSON.stringify(result.hits.hits);
  }
}
