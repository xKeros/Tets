// elasticsearch.service.ts
import { Injectable } from '@nestjs/common';
import { Client } from '@elastic/elasticsearch';

@Injectable()
export class ElasticsearchService {
  private readonly esClient: Client;

  constructor() {
    this.esClient = new Client({ node: 'http://localhost:9200' });
  }

  async search(index: string, query: any): Promise<any> {
    const result = await this.esClient.search({
      index,
      body: query,
    });

    return result; // Directamente devolver el resultado sin desestructurar
  }
}
