// elasticsearch.module.ts
import { Module } from '@nestjs/common';
import { ElasticsearchService } from './elasticsearch.service';
import { SearchResolver } from './elasticsearch.resolver';

@Module({
  providers: [ElasticsearchService, SearchResolver],
  exports: [ElasticsearchService],
})
export class ElasticsearchModule {}
