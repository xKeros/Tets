interface ObjectId {
  $oid: string;
}

interface Resolved {
  _id: string;
}

interface Team {
  name: string;
  home: boolean;
  resolved: Resolved;
}

interface Sport {
  id: string;
  name: string;
}

interface LeagueAlias {
  name: string;
  shortname: string;
  providerId: string;
  providerGroup: string;
}

interface League {
  name: string;
  shortname: string;
  description: string;
  country: string;
  sport: Sport;
  id: string;
  aliases: LeagueAlias[];
}

export interface EventDTO {
  _id: ObjectId;
  description: string;
  timestamp: number;
  teams: Team[];
  league: League;
  providerId: string;
  providerGroup: string;
}
