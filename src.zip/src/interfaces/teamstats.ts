import { Document } from 'mongoose';

interface StatsCategory {
  overAllWon: number;
  overAllLost: number;
  awayWon: number;
  awayLost: number;
  homeWon: number;
  homeLost: number;
  favWon: number;
  favLost: number;
  udogWon: number;
  udogLost: number;
  overAllTie: number;
  awayTie: number;
  homeTie: number;
  favTie: number;
  udogTie: number;
}

export interface TeamStatsDocument extends Document {
  stats: {
    ml: StatsCategory;
    ats: StatsCategory;
    uo: StatsCategory;
  };
}
