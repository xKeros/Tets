import { Document } from 'mongoose';

// Definición del subdocumento para 'sport'
interface Sport {
  id: string;
  name: string;
}

// Definición del documento principal
export interface LeagueDocument extends Document {
  name: string;
  shortname: string;
  description: string;
  country: string;
  sport: Sport;
}
