import { Document } from 'mongoose';

interface Team {
  name: string;
  home: boolean;
  resolved: {
    _id: string;
  };
}

interface League {
  name: string;
  shortname: string;
  description: string;
  country: string;
  sport: {
    id: string;
    name: string;
  };
  id: string;
  aliases: Array<{
    name: string;
    shortname: string;
    providerId: string;
    providerGroup: string;
  }>;
}

interface Alias {
  description: string;
  providerId: string;
  providerGroup: string;
  eventId: string;
}

interface Provider {
  _id: string; // Ajuste aquí: Mongoose usa ObjectId, pero en TypeScript usamos string para representarlo.
  primary: boolean;
  providerGroup: string; // Ajuste similar al campo _id.
}

interface Market {
  id: string;
  name: string;
}

export interface LineDocument extends Document {
  _id: string; // No es necesario definir el tipo de ObjectId aquí, string es suficiente para el uso con TypeScript.
  event: {
    description: string;
    timestamp: number;
    teams: Team[];
    league: League;
    providerId: string;
    providerGroup: string;
    id: string;
    aliases: Alias[];
  };
  book: {
    id: string;
    name: string;
  };
  line: {
    price: number;
    points: number;
  };
  provider: Provider;
  side: string;
  market: Market;
  timestamp: number;
}
