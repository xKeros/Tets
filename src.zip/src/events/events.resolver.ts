import { Resolver, Query } from '@nestjs/graphql';
import { EventsService } from './events.service';
import { EventType } from '../DTO/events.dto';

@Resolver()
export class EventsResolver {
  constructor(private readonly eventServices: EventsService) {}

  @Query(() => [EventType])
  async events() {
    return this.eventServices.findAll();
  }
}
