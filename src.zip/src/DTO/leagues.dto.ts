import { ObjectType, Field, ID } from '@nestjs/graphql';

@ObjectType()
export class SportType {
  @Field(() => ID)
  id: string;

  @Field()
  name: string;
}

@ObjectType()
export class LeagueDTO {
  @Field(() => ID)
  _id: string;

  @Field()
  name: string;

  @Field()
  shortname: string;

  @Field({ nullable: true })
  description?: string;

  @Field()
  country: string;

  @Field(() => SportType)
  sport: SportType;
}
