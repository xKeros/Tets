import { ObjectType, Field, ID, Int } from '@nestjs/graphql';

@ObjectType()
class Resolved {
  @Field(() => ID)
  _id: string;
}

@ObjectType()
class Team {
  @Field()
  name: string;

  @Field()
  home: boolean;

  @Field(() => Resolved)
  resolved: Resolved;
}

@ObjectType()
class Sport {
  @Field(() => ID)
  id: string;

  @Field()
  name: string;
}

@ObjectType()
class LeagueAlias {
  @Field()
  name: string;

  @Field()
  shortname: string;

  @Field(() => ID)
  providerId: string;

  @Field(() => ID)
  providerGroup: string;
}

@ObjectType()
class League {
  @Field()
  name: string;

  @Field()
  shortname: string;

  @Field({ nullable: true })
  description: string;

  @Field()
  country: string;

  @Field(() => Sport)
  sport: Sport;

  @Field(() => ID)
  id: string;

  @Field(() => [LeagueAlias])
  aliases: LeagueAlias[];
}

@ObjectType()
class Event {
  @Field()
  description: string;

  @Field(() => Int)
  timestamp: number;

  @Field(() => [Team])
  teams: Team[];

  @Field(() => League)
  league: League;

  @Field(() => [LeagueAlias])
  aliases: LeagueAlias[];

  @Field(() => ID)
  providerId: string;

  @Field(() => ID)
  providerGroup: string;

  @Field(() => ID)
  id: string;
}

@ObjectType()
class Book {
  @Field(() => ID)
  id: string;

  @Field()
  name: string;
}

@ObjectType()
class Line {
  @Field(() => Int)
  price: number;

  @Field(() => Int)
  points: number;
}

@ObjectType()
class Provider {
  @Field(() => ID)
  _id: string;

  @Field()
  primary: boolean;

  @Field(() => ID)
  providerGroup: string;
}

@ObjectType()
class Market {
  @Field(() => ID)
  id: string;

  @Field()
  name: string;
}

@ObjectType()
export class LineDTO {
  @Field(() => ID)
  _id: string;

  @Field(() => Event)
  event: Event;

  @Field(() => Book)
  book: Book;

  @Field(() => Line)
  line: Line;

  @Field(() => Provider)
  provider: Provider;

  @Field()
  side: string;

  @Field(() => Market)
  market: Market;

  @Field(() => Int)
  timestamp: number;
}
