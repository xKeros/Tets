import { ObjectType, Field, ID } from '@nestjs/graphql';
import { SportType } from './leagues.dto';

@ObjectType()
class AliasType {
  @Field()
  name: string;

  @Field()
  shortname: string;

  @Field()
  providerId: string;

  @Field()
  providerGroup: string;
}

@ObjectType()
class LeagueInfoType {
  @Field()
  name: string;

  @Field()
  shortname: string;

  @Field({ nullable: true })
  description?: string;

  @Field()
  country: string;

  @Field(() => SportType)
  sport: SportType;

  @Field(() => ID)
  id: string;

  @Field(() => [AliasType])
  aliases: AliasType[];
}

@ObjectType()
export class TeamDTO {
  @Field(() => ID)
  _id: string;

  @Field()
  name: string;

  @Field()
  shortname: string;

  @Field()
  nickname: string;

  @Field(() => LeagueInfoType)
  league: LeagueInfoType;
}
