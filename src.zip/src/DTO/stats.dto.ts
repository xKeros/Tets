import { ObjectType, Field, Int } from '@nestjs/graphql';
import { TeamDTO } from './team.dto';

@ObjectType()
class StatsCategoryType {
  @Field(() => Int)
  overAllWon: number;

  @Field(() => Int)
  overAllLost: number;

  @Field(() => Int, { nullable: true })
  awayWon?: number;

  @Field(() => Int, { nullable: true })
  awayLost?: number;

  @Field(() => Int, { nullable: true })
  homeWon?: number;

  @Field(() => Int, { nullable: true })
  homeLost?: number;

  @Field(() => Int, { nullable: true })
  favWon?: number;

  @Field(() => Int, { nullable: true })
  favLost?: number;

  @Field(() => Int, { nullable: true })
  udogWon?: number;

  @Field(() => Int, { nullable: true })
  udogLost?: number;

  @Field(() => Int, { nullable: true })
  overAllTie?: number;

  @Field(() => Int, { nullable: true })
  awayTie?: number;

  @Field(() => Int, { nullable: true })
  homeTie?: number;

  @Field(() => Int, { nullable: true })
  favTie?: number;

  @Field(() => Int, { nullable: true })
  udogTie?: number;
}

@ObjectType()
export class StatsType {
  @Field(() => StatsCategoryType)
  ml: StatsCategoryType;

  @Field(() => StatsCategoryType)
  ats: StatsCategoryType;

  @Field(() => StatsCategoryType)
  uo: StatsCategoryType;

  @Field(() => TeamDTO)
  team: TeamDTO;
}
