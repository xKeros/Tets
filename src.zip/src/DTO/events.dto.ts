import { ObjectType, Field, ID } from '@nestjs/graphql';
import { SportType } from './leagues.dto';

@ObjectType()
class ObjectIdType {
  @Field(() => ID)
  id: string;
}

@ObjectType()
class ResolvedType {
  @Field(() => ID)
  _id: string;
}

@ObjectType()
export class TeamType {
  @Field()
  name: string;

  @Field()
  home: boolean;

  @Field(() => ResolvedType)
  resolved: ResolvedType;
}

@ObjectType()
class LeagueAliasType {
  @Field()
  name: string;

  @Field()
  shortname: string;

  @Field()
  providerId: string;

  @Field()
  providerGroup: string;
}

@ObjectType()
export class LeagueType {
  @Field(() => ID)
  _id: string;

  @Field()
  name: string;

  @Field()
  shortname: string;

  @Field({ nullable: true })
  description?: string;

  @Field()
  country: string;

  @Field(() => SportType)
  sport: string;

  @Field(() => [LeagueAliasType])
  aliases: LeagueAliasType[];
}

@ObjectType()
export class EventType {
  @Field(() => ObjectIdType)
  _id: ObjectIdType;

  @Field()
  description: string;

  @Field()
  timestamp: number;

  @Field(() => [TeamType])
  teams: TeamType[];

  @Field(() => LeagueType)
  league: LeagueType;

  @Field()
  providerId: string;

  @Field()
  providerGroup: string;
}
