// team.module.ts
import { Module } from '@nestjs/common';
import { TeamsService } from './team.service';
import { TeamResolver } from './team.resolver';
import { MongooseModule } from '@nestjs/mongoose';
import { Team, TeamSchema } from '../Schema/team.schema';
// import { StatModule } from '../stats/stats.module'; // Asegúrate de ajustar la ruta según tu estructura

@Module({
  imports: [
    MongooseModule.forFeature([{ name: Team.name, schema: TeamSchema }]),
    //StatModule, // Importa StatModule aquí
  ],
  providers: [TeamsService, TeamResolver],
})
export class TeamModule {}
