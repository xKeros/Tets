import { Query, Resolver } from '@nestjs/graphql';
// Asegúrate de actualizar las importaciones según tus nombres actuales.
import { TeamDTO } from '../DTO/team.dto';
import { TeamsService } from './team.service';

@Resolver(() => TeamDTO)
export class TeamResolver {
  constructor(private readonly teamsService: TeamsService) {}

  @Query(() => [TeamDTO])
  async teams() {
    return this.teamsService.findAll();
  }
}
