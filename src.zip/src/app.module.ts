import { Module } from '@nestjs/common';
import { GraphQLModule } from '@nestjs/graphql';
import { ApolloDriver, ApolloDriverConfig } from '@nestjs/apollo';
import { join } from 'path';
import { MongooseModule } from '@nestjs/mongoose';
import { ElasticsearchModule } from './elasticsearch/elasticsearch.module';
import { LinesModule } from './lines/lines.module';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { LeaguesModule } from './leagues/leagues.module';
import { TeamModule } from './team/team.module';
import { EventsModule } from './events/events.module';
import { TeamStatsModule } from './stats/stats.module';

@Module({
  imports: [
    GraphQLModule.forRoot<ApolloDriverConfig>({
      driver: ApolloDriver,
      installSubscriptionHandlers: true, // Antes de la versión 7, para versiones más recientes revisa la nota abajo
      subscriptions: {
        'graphql-ws': true,
        'subscriptions-transport-ws': true,
      },
      autoSchemaFile: join(process.cwd(), 'src/schema.gql'),
    }),
    // Configuración dinámica para MongooseModule
    MongooseModule.forRootAsync({
      useFactory: () => ({
        uri: 'mongodb://localhost/api-feed',
        // Añadir aquí más opciones de configuración si es necesario
      }),
    }),
    ElasticsearchModule,
    LinesModule,
    LeaguesModule,
    TeamModule,
    EventsModule,
    TeamStatsModule,
  ],
  controllers: [AppController],
  providers: [
    AppService,
    {
      provide: 'ASYNC_CONNECTION',
      useFactory: async () => {
        console.log('Conexión a MongoDB establecida con éxito.');
        // Aquí puedes realizar operaciones adicionales si es necesario
      },
    },
  ],
})
export class AppModule {}
