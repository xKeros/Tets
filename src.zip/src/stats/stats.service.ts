import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { TeamStats } from '../Schema/stats.schema'; // Suponiendo que esta es tu clase de esquema Mongoose
import { StatsType } from '../DTO/stats.dto'; // Tu DTO

@Injectable()
export class TeamStatsService {
  constructor(
    @InjectModel(TeamStats.name)
    private teamStatsModel: Model<TeamStats>,
  ) {}

  async getTeamStats(): Promise<StatsType> {
    const teamStatsArray = await this.teamStatsModel.find().exec();

    // Asumiendo que solo trabajamos con el primer documento por simplicidad
    const teamStats = teamStatsArray[0];

    // Transforma los datos aquí. Este es un ejemplo simplificado. Deberías ajustarlo según tu lógica y estructura de datos.
    const transformedStats: StatsType = {
      ml: teamStats.stats.ml,
      ats: teamStats.stats.ats,
      uo: teamStats.stats.uo,
    };

    return transformedStats;
  }
}
