import { Resolver, Query } from '@nestjs/graphql';
import { TeamStatsService } from './stats.service'; // Asume que este servicio ya está implementado
import { StatsType } from '../DTO/stats.dto'; // Asume que este es el DTO que hemos definido

@Resolver(() => StatsType)
export class TeamStatsResolver {
  constructor(private teamStatsService: TeamStatsService) {}

  @Query(() => StatsType)
  async teamStats(): Promise<StatsType> {
    return this.teamStatsService.getTeamStats(); // Asume que este método devuelve los datos necesarios
  }
}
