import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { TeamStatsService } from './stats.service';
import { TeamStatsResolver } from './stats.resolver';
import { TeamStats, TeamStatsSchema } from 'src/Schema/stats.schema'; // Ajusta la ruta según tu estructura

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: TeamStats.name, schema: TeamStatsSchema },
    ]),
  ],
  providers: [TeamStatsService, TeamStatsResolver],
})
export class TeamStatsModule {}
