import { Test, TestingModule } from '@nestjs/testing';
import { LeaguesResolver } from './leagues.resolver';

describe('LeaguesResolver', () => {
  let resolver: LeaguesResolver;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [LeaguesResolver],
    }).compile();

    resolver = module.get<LeaguesResolver>(LeaguesResolver);
  });

  it('should be defined', () => {
    expect(resolver).toBeDefined();
  });
});
