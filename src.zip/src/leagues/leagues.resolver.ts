import { Query, Resolver } from '@nestjs/graphql';
import { LeagueDTO } from '../DTO/leagues.dto';
import { LeaguesService } from './league.service';

@Resolver(() => LeagueDTO)
export class LeagueResolver {
  constructor(private readonly leaguesService: LeaguesService) {}

  @Query(() => [LeagueDTO])
  async leagues() {
    return this.leaguesService.findAll();
  }
}
