import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { League, LeagueSchema } from '../Schema/leagues.schema';
import { LeaguesService } from './league.service';
import { LeagueResolver } from './leagues.resolver';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: League.name, schema: LeagueSchema }]),
  ],
  providers: [LeaguesService, LeagueResolver],
})
export class LeaguesModule {}
